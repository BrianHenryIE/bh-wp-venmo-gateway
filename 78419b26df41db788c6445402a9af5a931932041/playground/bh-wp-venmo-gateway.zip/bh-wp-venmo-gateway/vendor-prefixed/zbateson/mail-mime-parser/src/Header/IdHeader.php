<?php
/**
 * This file is part of the ZBateson\MailMimeParser project.
 *
 * @license http://opensource.org/licenses/bsd-license.php BSD
 */

namespace BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Header;

use BrianHenryIE\WP_Venmo_Gateway\Psr\Log\LoggerInterface;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Header\Consumer\IdBaseConsumerService;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Header\Part\CommentPart;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Header\Part\MimeTokenPartFactory;

/**
 * Represents a Content-ID, Message-ID, In-Reply-To or References header.
 *
 * For a multi-id header like In-Reply-To or References, all IDs can be
 * retrieved by calling {@see IdHeader::getIds()}.  Otherwise, to retrieve the
 * first (or only) ID call {@see IdHeader::getValue()}.
 *
 * @author Zaahid Bateson
 */
class IdHeader extends MimeEncodedHeader
{
    public function __construct(
        string $name,
        string $value,
        ?LoggerInterface $logger = null,
        ?MimeTokenPartFactory $mimeTokenPartFactory = null,
        ?IdBaseConsumerService $consumerService = null,
        ?int $maxTokenCount = null
    ) {
        parent::__construct(
            self::resolveService($logger, LoggerInterface::class),
            self::resolveService($mimeTokenPartFactory, MimeTokenPartFactory::class),
            self::resolveService($consumerService, IdBaseConsumerService::class),
            $name,
            $value,
            $maxTokenCount
        );
    }

    /**
     * Returns the ID. Synonymous to calling getValue().
     *
     * @return string|null The ID
     */
    public function getId() : ?string
    {
        return $this->getValue();
    }

    /**
     * Returns all IDs parsed for a multi-id header like References or
     * In-Reply-To.
     *
     * @return string[] An array of IDs
     */
    public function getIds() : array
    {
        return \array_values(\array_map(
            fn($p) => $p->getValue(),
            \array_filter($this->parts, fn($p) => !($p instanceof CommentPart))
        ));
    }
}
