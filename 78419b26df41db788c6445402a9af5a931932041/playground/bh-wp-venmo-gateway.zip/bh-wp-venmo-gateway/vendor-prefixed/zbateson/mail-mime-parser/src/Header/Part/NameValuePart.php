<?php
/**
 * This file is part of the ZBateson\MailMimeParser project.
 *
 * @license http://opensource.org/licenses/bsd-license.php BSD
 */

namespace BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Header\Part;

use BrianHenryIE\WP_Venmo_Gateway\Psr\Log\LoggerInterface;
use BrianHenryIE\WP_Venmo_Gateway\Psr\Log\LogLevel;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\ErrorBag;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Header\IHeaderPart;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MbWrapper\MbWrapper;

/**
 * Represents a name/value pair part of a header.
 *
 * @author Zaahid Bateson
 */
class NameValuePart extends ContainerPart
{
    /**
     * @var string the name of the part
     */
    protected string $name;

    /**
     * @param array<IHeaderPart> $nameParts
     * @param array<IHeaderPart> $valueParts
     */
    public function __construct(
        LoggerInterface $logger,
        MbWrapper $charsetConverter,
        array $nameParts,
        array $valueParts
    ) {
        ErrorBag::__construct($logger);
        $this->charsetConverter = $charsetConverter;
        $this->name = (!empty($nameParts)) ? $this->getNameFromParts($nameParts) : '';
        parent::__construct($logger, $charsetConverter, $valueParts);
        \array_unshift($this->children, ...$nameParts);
    }

    /**
     * Creates the string 'name' representation of this part constructed from
     * the child name parts passed to it.
     *
     * @param IHeaderPart[] $parts
     */
    protected function getNameFromParts(array $parts) : string
    {
        return \implode('', \array_map(fn ($p) => $p->getValue(), $this->filterIgnoredSpaces($parts)));
    }

    /**
     * Returns the name of the name/value part.
     */
    public function getName() : string
    {
        return $this->name;
    }

    protected function validate() : void
    {
        if ($this->value === '') {
            $this->addError('NameValuePart value is empty', LogLevel::NOTICE);
        }
    }
}
