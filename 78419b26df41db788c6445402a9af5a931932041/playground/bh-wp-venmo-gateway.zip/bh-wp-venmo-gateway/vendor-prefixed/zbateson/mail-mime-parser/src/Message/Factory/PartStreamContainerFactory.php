<?php
/**
 * This file is part of the ZBateson\MailMimeParser project.
 *
 * @license http://opensource.org/licenses/bsd-license.php BSD
 */

namespace BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Message\Factory;

use BrianHenryIE\WP_Venmo_Gateway\Psr\Log\LoggerInterface;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Message\PartStreamContainer;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Stream\StreamFactory;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MbWrapper\MbWrapper;

/**
 * Creates PartStreamContainer instances.
 *
 * @author Zaahid Bateson
 */
class PartStreamContainerFactory
{
    public function __construct(
        protected readonly LoggerInterface $logger,
        protected readonly StreamFactory $streamFactory,
        protected readonly MbWrapper $mbWrapper,
        protected readonly bool $throwExceptionReadingPartContentFromUnsupportedCharsets
    ) {
    }

    public function newInstance() : PartStreamContainer
    {
        return new PartStreamContainer(
            $this->logger,
            $this->streamFactory,
            $this->mbWrapper,
            $this->throwExceptionReadingPartContentFromUnsupportedCharsets
        );
    }
}
