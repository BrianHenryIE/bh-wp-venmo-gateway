<?php
/**
 * This file is part of the ZBateson\MailMimeParser project.
 *
 * @license http://opensource.org/licenses/bsd-license.php BSD
 */

namespace BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Message\Factory;

use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Message\PartChildrenContainer;

/**
 * Creates PartChildrenContainer instances.
 *
 * @author Zaahid Bateson
 */
class PartChildrenContainerFactory
{
    public function newInstance() : PartChildrenContainer
    {
        return new PartChildrenContainer();
    }
}
