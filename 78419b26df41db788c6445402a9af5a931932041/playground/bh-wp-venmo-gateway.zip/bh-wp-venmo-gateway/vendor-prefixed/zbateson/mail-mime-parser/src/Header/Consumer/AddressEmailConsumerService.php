<?php
/**
 * This file is part of the ZBateson\MailMimeParser project.
 *
 * @license http://opensource.org/licenses/bsd-license.php BSD
 */

namespace BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Header\Consumer;

use BrianHenryIE\WP_Venmo_Gateway\Psr\Log\LoggerInterface;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Header\Part\HeaderPartFactory;

/**
 * Parses the Address portion of an email address header, for an address part
 * that contains both a name and an email address, e.g. "name" <email@tld.com>.
 *
 * The address portion found within the '<' and '>' chars may contain comments
 * and quoted portions.
 *
 * @author Zaahid Bateson
 */
class AddressEmailConsumerService extends AbstractConsumerService
{
    public function __construct(
        LoggerInterface $logger,
        HeaderPartFactory $partFactory,
        CommentConsumerService $commentConsumerService,
        QuotedStringConsumerService $quotedStringConsumerService
    ) {
        parent::__construct(
            $logger,
            $partFactory,
            [$commentConsumerService, $quotedStringConsumerService]
        );
    }

    /**
     * Overridden to return patterns matching the beginning/end part of an
     * address in a name/address part ("<" and ">" chars).
     *
     * @return string[] the patterns
     */
    public function getTokenSeparators() : array
    {
        return ['<', '>'];
    }

    /**
     * Returns true for the '>' char.
     */
    protected function isEndToken(string $token) : bool
    {
        return ($token === '>');
    }

    /**
     * Returns true for the '<' char.
     */
    protected function isStartToken(string $token) : bool
    {
        return ($token === '<');
    }

    /**
     * Returns a single {@see BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Header\Part\AddressPart}
     * with its 'email' portion set, so an {@see AddressConsumerService} can
     * identify it and create an
     * {@see BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Header\Part\AddressPart} Address with
     * both a name and email set.
     *
     * @param \BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Header\IHeaderPart[] $parts
     * @return \BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Header\IHeaderPart[]|array
     */
    protected function processParts(array $parts) : array
    {
        return [$this->partFactory->newAddress([], $parts)];
    }
}
