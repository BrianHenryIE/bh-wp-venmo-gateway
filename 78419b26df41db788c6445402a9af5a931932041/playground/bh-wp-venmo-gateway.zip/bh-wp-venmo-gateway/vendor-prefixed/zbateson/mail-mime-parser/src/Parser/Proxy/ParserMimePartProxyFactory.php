<?php
/**
 * This file is part of the ZBateson\MailMimeParser project.
 *
 * @license http://opensource.org/licenses/bsd-license.php BSD
 */

namespace BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Parser\Proxy;

use BrianHenryIE\WP_Venmo_Gateway\Psr\Log\LoggerInterface;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Message\Factory\PartHeaderContainerFactory;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Message\IMimePart;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Message\MimePart;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Parser\IParserService;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Parser\Part\ParserPartChildrenContainerFactory;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Parser\Part\ParserPartStreamContainerFactory;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Parser\PartBuilder;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Stream\StreamFactory;

/**
 * Responsible for creating proxied IMimePart instances wrapped in a
 * ParserMimePartProxy with a MimeParser.
 *
 * @author Zaahid Bateson
 */
class ParserMimePartProxyFactory extends ParserPartProxyFactory
{
    public function __construct(
        protected readonly LoggerInterface $logger,
        protected readonly StreamFactory $streamFactory,
        protected readonly PartHeaderContainerFactory $partHeaderContainerFactory,
        protected readonly ParserPartStreamContainerFactory $parserPartStreamContainerFactory,
        protected readonly ParserPartChildrenContainerFactory $parserPartChildrenContainerFactory,
        protected readonly string $defaultFallbackCharset = 'ISO-8859-1'
    ) {
    }

    /**
     * Constructs a new ParserMimePartProxy wrapping an IMimePart object that
     * will dynamically parse a message's content and parts as they're
     * requested.
     */
    public function newInstance(PartBuilder $partBuilder, IParserService $parser) : ParserMimePartProxy
    {
        $parserProxy = new ParserMimePartProxy($partBuilder, $parser);

        // parsed before the part's header container copies the parser's header
        // objects, so the part reuses it rather than parsing it a second time
        $parserProxy->getContentType();

        $streamContainer = $this->parserPartStreamContainerFactory->newInstance($parserProxy);
        $headerContainer = $this->partHeaderContainerFactory->newInstance($parserProxy->getHeaderContainer());
        $childrenContainer = $this->parserPartChildrenContainerFactory->newInstance($parserProxy);

        $parent = $partBuilder->getParent()?->getPart();
        \assert($parent === null || $parent instanceof IMimePart);
        $part = new MimePart(
            $parent,
            $this->logger,
            $streamContainer,
            $headerContainer,
            $childrenContainer,
            $this->defaultFallbackCharset
        );
        $parserProxy->setPart($part);

        $streamContainer->setStream($this->streamFactory->newMessagePartStream($part));
        $part->attach($streamContainer);
        return $parserProxy;
    }
}
