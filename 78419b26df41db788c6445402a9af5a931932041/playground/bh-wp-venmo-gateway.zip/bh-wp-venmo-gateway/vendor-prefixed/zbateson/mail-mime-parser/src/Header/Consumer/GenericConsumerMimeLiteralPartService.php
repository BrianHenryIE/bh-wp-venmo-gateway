<?php
/**
 * This file is part of the ZBateson\MailMimeParser project.
 *
 * @license http://opensource.org/licenses/bsd-license.php BSD
 */

namespace BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Header\Consumer;

use BrianHenryIE\WP_Venmo_Gateway\Psr\Log\LoggerInterface;
use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Header\Part\MimeTokenPartFactory;

/**
 * GenericConsumerMimeLiteralPartService uses a MimeTokenPartFactory instead
 * of a HeaderPartFactory.
 *
 * @author Zaahid Bateson
 */
class GenericConsumerMimeLiteralPartService extends GenericConsumerService
{
    public function __construct(
        LoggerInterface $logger,
        MimeTokenPartFactory $partFactory,
        CommentConsumerService $commentConsumerService,
        QuotedStringConsumerService $quotedStringConsumerService,
        int $maxHeaderTokenCount = 20000
    ) {
        parent::__construct(
            $logger,
            $partFactory,
            $commentConsumerService,
            $quotedStringConsumerService,
            $maxHeaderTokenCount
        );
    }
}
