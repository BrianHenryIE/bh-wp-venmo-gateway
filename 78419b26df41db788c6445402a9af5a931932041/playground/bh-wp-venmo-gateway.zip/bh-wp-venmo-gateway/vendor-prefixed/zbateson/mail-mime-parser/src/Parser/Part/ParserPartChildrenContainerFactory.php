<?php
/**
 * This file is part of the ZBateson\MailMimeParser project.
 *
 * @license http://opensource.org/licenses/bsd-license.php BSD
 */

namespace BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Parser\Part;

use BrianHenryIE\WP_Venmo_Gateway\ZBateson\MailMimeParser\Parser\Proxy\ParserMimePartProxy;

/**
 * Creates ParserPartChildrenContainer instances.
 *
 * @author Zaahid Bateson
 */
class ParserPartChildrenContainerFactory
{
    public function newInstance(ParserMimePartProxy $parserProxy) : ParserPartChildrenContainer
    {
        return new ParserPartChildrenContainer($parserProxy);
    }
}
