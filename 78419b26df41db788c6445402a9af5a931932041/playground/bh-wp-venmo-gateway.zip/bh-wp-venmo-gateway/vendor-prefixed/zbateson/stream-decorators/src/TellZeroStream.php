<?php
/**
 * This file is part of the ZBateson\StreamDecorators project.
 *
 * @license http://opensource.org/licenses/bsd-license.php BSD
 */

namespace BrianHenryIE\WP_Venmo_Gateway\ZBateson\StreamDecorators;

use BrianHenryIE\WP_Venmo_Gateway\Psr\Http\Message\StreamInterface;
use BrianHenryIE\WP_Venmo_Gateway\GuzzleHttp\Psr7\StreamDecoratorTrait;

/**
 * Calling tell() always returns 0.  Used by DecoratedCachingStream so a
 * CachingStream can use a BufferedStream, because BufferedStream throws an
 * exception in tell().
 */
class TellZeroStream implements StreamInterface
{
    use StreamDecoratorTrait;

    /**
     * @var StreamInterface
     * @phpstan-ignore-next-line
     */
    private readonly StreamInterface $stream;

    public function tell() : int
    {
        return 0;
    }
}
