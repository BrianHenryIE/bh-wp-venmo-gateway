<?php declare(strict_types=1);

/*
 * This file is part of the Monolog package.
 *
 * (c) Jordi Boggiano <j.boggiano@seld.be>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace JuicedPlugins\Venmo_Gateway_Pro\Monolog\Processor;

use JuicedPlugins\Venmo_Gateway_Pro\Monolog\LogRecord;

/**
 * Injects memory_get_usage in all records
 *
 * @see JuicedPlugins\Venmo_Gateway_Pro\Monolog\Processor\MemoryProcessor::__construct() for options
 * @author Rob Jensen
 */
class MemoryUsageProcessor extends MemoryProcessor
{
    /**
     * @inheritDoc
     */
    public function __invoke(LogRecord $record): LogRecord
    {
        $usage = memory_get_usage($this->realUsage);

        if ($this->useFormatting) {
            $usage = $this->formatBytes($usage);
        }

        $record->extra['memory_usage'] = $usage;

        return $record;
    }
}
