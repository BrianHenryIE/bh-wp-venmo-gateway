<?php
/**
 * This file is part of the ZBateson\StreamDecorators project.
 *
 * @license http://opensource.org/licenses/bsd-license.php BSD
 */

namespace JuicedPlugins\Venmo_Gateway_Pro\ZBateson\StreamDecorators;

use JuicedPlugins\Venmo_Gateway_Pro\Psr\Http\Message\StreamInterface;
use JuicedPlugins\Venmo_Gateway_Pro\GuzzleHttp\Psr7\StreamDecoratorTrait;

/**
 * Calling tell() always returns 0.  Used by DecoratedCachingStream so a
 * CachingStream can use a BufferedStream, because BufferedStream throws an
 * exception in tell().
 */
class TellZeroStream implements StreamInterface
{
    use StreamDecoratorTrait;

    /**
     * @var StreamInterface
     * @phpstan-ignore-next-line
     */
    private readonly StreamInterface $stream;

    public function tell() : int
    {
        return 0;
    }
}
