<?php
/**
 * This file is part of the ZBateson\MailMimeParser project.
 *
 * @license http://opensource.org/licenses/bsd-license.php BSD
 */

use JuicedPlugins\Venmo_Gateway_Pro\DI\Definition\Helper\AutowireDefinitionHelper;
use JuicedPlugins\Venmo_Gateway_Pro\DI\Definition\Reference;
use JuicedPlugins\Venmo_Gateway_Pro\Psr\Log\LoggerInterface;
use JuicedPlugins\Venmo_Gateway_Pro\Psr\Log\NullLogger;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Header\Consumer\AddressBaseConsumerService;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Header\Consumer\CommentConsumerService;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Header\Consumer\DateConsumerService;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Header\Consumer\GenericConsumerMimeLiteralPartService;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Header\Consumer\IdBaseConsumerService;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Header\Consumer\ParameterConsumerService;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Header\Consumer\Received\DomainConsumerService;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Header\Consumer\Received\GenericReceivedConsumerService;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Header\Consumer\ReceivedConsumerService;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Header\Consumer\SubjectConsumerService;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Message\Factory\IMessagePartFactory;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Message\Factory\IMimePartFactory;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Message\Factory\IUUEncodedPartFactory;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Message\Factory\PartHeaderContainerFactory;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Message\Factory\PartStreamContainerFactory;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Message\PartStreamContainer;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Parser\HeaderParserService;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Parser\MimeParserService;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Parser\NonMimeParserService;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Parser\Part\ParserPartStreamContainerFactory;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Parser\Proxy\ParserMessageProxyFactory;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Parser\Proxy\ParserMimePartProxyFactory;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Parser\Proxy\ParserNonMimeMessageProxyFactory;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Parser\Proxy\ParserUUEncodedPartProxyFactory;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Stream\StreamFactory;

return [
    LoggerInterface::class => new AutowireDefinitionHelper(NullLogger::class),

    // only affects reading part content, not for instance decoding mime encoded
    // header parts
    'throwExceptionReadingPartContentFromUnsupportedCharsets' => false,

    // Fallback charset for text/* content parts without a declared charset.
    // Per RFC 2045, the default is ISO-8859-1 but many modern messages omit the
    // charset and are actually UTF-8.  Override this to 'UTF-8' if desired.
    'defaultFallbackCharset' => 'ISO-8859-1',

    // Maximum multipart nesting depth before parsing stops with a recorded error.
    'maxMimePartDepth' => 256,

    // Maximum header count and total header bytes before parsing stops.
    'maxHeaderCount' => 1000,
    'maxHeaderSizeBytes' => 1048576,

    // Maximum number of parts (mime and uu-encoded) in a single message before
    // parsing stops with a recorded error.
    'maxMessagePartCount' => 1000,

    // Maximum number of headers, and total header bytes, read across all parts
    // of a single message before parsing stops with a recorded error.
    'maxMessageHeaderCount' => 50000,
    'maxMessageHeaderSizeBytes' => 8388608,

    // Maximum nesting depth of parenthesized comments in a header value.
    // Comments deeper than this are still parsed over but not kept.
    'maxCommentDepth' => 32,

    // Maximum number of tokens parsed out of a single header's value.  Past
    // this the remainder is kept as one unparsed token and an error recorded.
    'maxHeaderTokenCount' => 20000,

    // Maximum number of header tokens parsed across all headers of a single
    // message.  Headers parsed past this are kept as one unparsed token each
    // and an error recorded.
    'maxMessageHeaderTokenCount' => 250000,

    'fromDomainConsumerService' => (new AutowireDefinitionHelper(DomainConsumerService::class))
        ->constructorParameter('partName', 'from'),
    'byDomainConsumerService' => (new AutowireDefinitionHelper(DomainConsumerService::class))
        ->constructorParameter('partName', 'by'),
    'viaGenericReceivedConsumerService' => (new AutowireDefinitionHelper(GenericReceivedConsumerService::class))
        ->constructorParameter('partName', 'via'),
    'withGenericReceivedConsumerService' => (new AutowireDefinitionHelper(GenericReceivedConsumerService::class))
        ->constructorParameter('partName', 'with'),
    'idGenericReceivedConsumerService' => (new AutowireDefinitionHelper(GenericReceivedConsumerService::class))
        ->constructorParameter('partName', 'id'),
    'forGenericReceivedConsumerService' => (new AutowireDefinitionHelper(GenericReceivedConsumerService::class))
        ->constructorParameter('partName', 'for'),
    CommentConsumerService::class => (new AutowireDefinitionHelper())
        ->constructor(
            maxCommentDepth: new Reference('maxCommentDepth')
        ),
    AddressBaseConsumerService::class => (new AutowireDefinitionHelper())
        ->constructor(
            maxHeaderTokenCount: new Reference('maxHeaderTokenCount')
        ),
    DateConsumerService::class => (new AutowireDefinitionHelper())
        ->constructor(
            maxHeaderTokenCount: new Reference('maxHeaderTokenCount')
        ),
    GenericConsumerMimeLiteralPartService::class => (new AutowireDefinitionHelper())
        ->constructor(
            maxHeaderTokenCount: new Reference('maxHeaderTokenCount')
        ),
    IdBaseConsumerService::class => (new AutowireDefinitionHelper())
        ->constructor(
            maxHeaderTokenCount: new Reference('maxHeaderTokenCount')
        ),
    ParameterConsumerService::class => (new AutowireDefinitionHelper())
        ->constructor(
            maxHeaderTokenCount: new Reference('maxHeaderTokenCount')
        ),
    SubjectConsumerService::class => (new AutowireDefinitionHelper())
        ->constructor(
            maxHeaderTokenCount: new Reference('maxHeaderTokenCount')
        ),
    ReceivedConsumerService::class => (new AutowireDefinitionHelper())
        ->constructor(
            fromDomainConsumerService: new Reference('fromDomainConsumerService'),
            byDomainConsumerService: new Reference('byDomainConsumerService'),
            viaGenericReceivedConsumerService: new Reference('viaGenericReceivedConsumerService'),
            withGenericReceivedConsumerService: new Reference('withGenericReceivedConsumerService'),
            idGenericReceivedConsumerService: new Reference('idGenericReceivedConsumerService'),
            forGenericReceivedConsumerService: new Reference('forGenericReceivedConsumerService'),
            maxHeaderTokenCount: new Reference('maxHeaderTokenCount')
        ),
    PartStreamContainer::class => (new AutowireDefinitionHelper())
        ->constructor(
            throwExceptionReadingPartContentFromUnsupportedCharsets: new Reference('throwExceptionReadingPartContentFromUnsupportedCharsets')
        ),
    PartStreamContainerFactory::class => (new AutowireDefinitionHelper())
        ->constructor(
            throwExceptionReadingPartContentFromUnsupportedCharsets: new Reference('throwExceptionReadingPartContentFromUnsupportedCharsets')
        ),
    ParserPartStreamContainerFactory::class => (new AutowireDefinitionHelper())
        ->constructor(
            throwExceptionReadingPartContentFromUnsupportedCharsets: new Reference('throwExceptionReadingPartContentFromUnsupportedCharsets')
        ),
    StreamFactory::class => (new AutowireDefinitionHelper())
        ->constructor(
            throwExceptionReadingPartContentFromUnsupportedCharsets: new Reference('throwExceptionReadingPartContentFromUnsupportedCharsets')
        ),
    IMessagePartFactory::class => (new AutowireDefinitionHelper())
        ->constructor(
            defaultFallbackCharset: new Reference('defaultFallbackCharset')
        ),
    IMimePartFactory::class => (new AutowireDefinitionHelper())
        ->constructor(
            defaultFallbackCharset: new Reference('defaultFallbackCharset')
        ),
    IUUEncodedPartFactory::class => (new AutowireDefinitionHelper())
        ->constructor(
            defaultFallbackCharset: new Reference('defaultFallbackCharset')
        ),
    ParserMimePartProxyFactory::class => (new AutowireDefinitionHelper())
        ->constructor(
            defaultFallbackCharset: new Reference('defaultFallbackCharset')
        ),
    ParserUUEncodedPartProxyFactory::class => (new AutowireDefinitionHelper())
        ->constructor(
            defaultFallbackCharset: new Reference('defaultFallbackCharset')
        ),
    ParserMessageProxyFactory::class => (new AutowireDefinitionHelper())
        ->constructor(
            defaultFallbackCharset: new Reference('defaultFallbackCharset')
        ),
    ParserNonMimeMessageProxyFactory::class => (new AutowireDefinitionHelper())
        ->constructor(
            defaultFallbackCharset: new Reference('defaultFallbackCharset')
        ),
    PartHeaderContainerFactory::class => (new AutowireDefinitionHelper())
        ->constructor(
            maxMessageHeaderTokenCount: new Reference('maxMessageHeaderTokenCount'),
            maxMessageHeaderCount: new Reference('maxMessageHeaderCount'),
            maxMessageHeaderSizeBytes: new Reference('maxMessageHeaderSizeBytes')
        ),
    HeaderParserService::class => (new AutowireDefinitionHelper())
        ->constructor(
            maxHeaderCount: new Reference('maxHeaderCount'),
            maxHeaderSizeBytes: new Reference('maxHeaderSizeBytes')
        ),
    MimeParserService::class => (new AutowireDefinitionHelper())
        ->constructor(
            maxMimePartDepth: new Reference('maxMimePartDepth'),
            maxMessagePartCount: new Reference('maxMessagePartCount')
        ),
    NonMimeParserService::class => (new AutowireDefinitionHelper())
        ->constructor(
            maxMessagePartCount: new Reference('maxMessagePartCount')
        ),
];
