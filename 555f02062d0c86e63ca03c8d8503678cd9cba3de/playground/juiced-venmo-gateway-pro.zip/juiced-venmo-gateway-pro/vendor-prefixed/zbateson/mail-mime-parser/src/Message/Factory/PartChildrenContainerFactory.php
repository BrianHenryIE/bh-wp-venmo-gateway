<?php
/**
 * This file is part of the ZBateson\MailMimeParser project.
 *
 * @license http://opensource.org/licenses/bsd-license.php BSD
 */

namespace JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Message\Factory;

use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Message\PartChildrenContainer;

/**
 * Creates PartChildrenContainer instances.
 *
 * @author Zaahid Bateson
 */
class PartChildrenContainerFactory
{
    public function newInstance() : PartChildrenContainer
    {
        return new PartChildrenContainer();
    }
}
