<?php
/**
 * This file is part of the ZBateson\MailMimeParser project.
 *
 * @license http://opensource.org/licenses/bsd-license.php BSD
 */

namespace JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Parser\Part;

use JuicedPlugins\Venmo_Gateway_Pro\Psr\Log\LoggerInterface;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Header\HeaderFactory;

/**
 * Creates UUEncodedPartHeaderContainer instances.
 *
 * @author Zaahid Bateson
 */
class UUEncodedPartHeaderContainerFactory
{
    public function __construct(
        protected readonly LoggerInterface $logger,
        protected readonly HeaderFactory $headerFactory
    ) {
    }

    /**
     * Creates and returns a UUEncodedPartHeaderContainer.
     */
    public function newInstance(int $mode, string $filename) : UUEncodedPartHeaderContainer
    {
        $container = new UUEncodedPartHeaderContainer($this->logger, $this->headerFactory);
        $container->setUnixFileMode($mode);
        $container->setFilename($filename);
        return $container;
    }
}
