<?php
/**
 * This file is part of the ZBateson\MailMimeParser project.
 *
 * @license http://opensource.org/licenses/bsd-license.php BSD
 */

namespace JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Stream;

use ArrayIterator;
use JuicedPlugins\Venmo_Gateway_Pro\GuzzleHttp\Psr7;
use JuicedPlugins\Venmo_Gateway_Pro\Psr\Http\Message\StreamInterface;
use SplObserver;
use SplSubject;
use Traversable;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Header\HeaderConsts;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Message\IMessagePart;
use JuicedPlugins\Venmo_Gateway_Pro\ZBateson\MailMimeParser\Message\IMimePart;

/**
 * Psr7 stream decorator implementation providing a readable stream for a part's
 * headers.
 *
 * HeaderStream is only used by a MimePart parent.  It can accept any
 * MessagePart - for non-MimeParts, only type headers are generated based on
 * available information.
 *
 * @author Zaahid Bateson
 */
class HeaderStream extends MessagePartStreamDecorator implements SplObserver, StreamInterface
{
    /**
     * @var IMessagePart the part to read from.
     */
    protected IMessagePart $part;

    public function __construct(IMessagePart $part)
    {
        parent::__construct($part);
        $part->attach($this);

        // Don't initialize $stream - let the StreamDecoratorTrait's __get()
        // call createStream() lazily when needed.
    }

    public function __destruct()
    {
        $this->part->detach($this);
    }

    public function update(SplSubject $subject) : void
    {
        if ($this->stream !== null) {
            $this->stream = $this->createStream();
        }
    }

    /**
     * Returns a header array for the current part.
     *
     * If the part is not a MimePart, Content-Type, Content-Disposition and
     * Content-Transfer-Encoding headers are generated manually.
     *
     * @return Traversable<int, array{0: string, 1: string}>
     */
    private function getPartHeadersIterator() : Traversable
    {
        if ($this->part instanceof IMimePart) {
            return $this->part->getRawHeaderIterator();
        } elseif ($this->part->getParent()?->isMime()) {
            return new ArrayIterator([
                [HeaderConsts::CONTENT_TYPE, $this->part->getContentType()],
                [HeaderConsts::CONTENT_DISPOSITION, $this->part->getContentDisposition()],
                [HeaderConsts::CONTENT_TRANSFER_ENCODING, $this->part->getContentTransferEncoding()]
            ]);
        }
        return new ArrayIterator();
    }

    /**
     * Writes out headers for $this->part and follows them with an empty line.
     */
    public function writePartHeadersTo(StreamInterface $stream) : static
    {
        foreach ($this->getPartHeadersIterator() as $header) {
            $stream->write("{$header[0]}: {$header[1]}\r\n");
        }
        $stream->write("\r\n");
        return $this;
    }

    /**
     * Creates the underlying stream lazily when required.
     */
    protected function createStream() : StreamInterface
    {
        $stream = Psr7\Utils::streamFor();
        $this->writePartHeadersTo($stream);
        $stream->rewind();
        return $stream;
    }
}
